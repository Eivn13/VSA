/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rest;

import java.util.ArrayList;
import java.util.List;
import javax.inject.Singleton;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author xpruzinsky
 */
@Path("zoznam")
@Singleton  //toto potrebujeme inak sa nebudu ukladat hodnoty
public class ZoznamResource {

    @Context
    private UriInfo context;
    
    private List<String> aaa;
    /**
     * Creates a new instance of ZoznamResource
     */
    public ZoznamResource() {
        aaa  = new ArrayList();
        aaa.add("Hlupa");
        aaa.add("klavesnica");
    }

    /**
     * Retrieves representation of an instance of rest.ZoznamResource
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String getText() {
        StringBuilder sb = new StringBuilder(50);
        for (String s : aaa){
            sb.append(s);
        }/*
        sb.append(aaa.get(x));
        sb.append("\n");
        */
        return sb.toString();
        
    }

    /**
     * PUT method for updating or creating an instance of ZoznamResource
     * @param content representation for the resource 
     * @return  
     */
    @PUT
    @Consumes(MediaType.TEXT_PLAIN)
    public String putText(String content) {
        aaa.add(content);
        return aaa.get(2);//content;
    }
}
